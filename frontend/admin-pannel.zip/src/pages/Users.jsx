const Users = () => {
  return <div className="h-[100vh] border-4 ">Users</div>;
};

export default Users;
