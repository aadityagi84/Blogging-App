import Router from "./routes/Route";

const App = () => {
  return (
    <div>
      <Router />
    </div>
  );
};

export default App;
